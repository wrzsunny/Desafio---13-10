const CHAVE_TAREFAS = "tarefasApp_tarefas";
const CHAVE_TEMA = "tarefasApp_tema";

const inputTarefa = document.getElementById("inputTarefa");
const btnAdicionar = document.getElementById("btnAdicionar");
const listaTarefas = document.getElementById("listaTarefas");
const resumo = document.getElementById("resumo");
const btnLimpar = document.getElementById("btnLimpar");
const btnTema = document.getElementById("btnTema");

function carregarTarefas() {
  try {
    const salvas = JSON.parse(localStorage.getItem(CHAVE_TAREFAS));
    return Array.isArray(salvas) ? salvas : [];
  } catch (erro) {
    console.error("Dado inválido no localStorage:", erro);
    return [];
  }
}

let tarefas = carregarTarefas();

function salvarTarefas() {
  localStorage.setItem(CHAVE_TAREFAS, JSON.stringify(tarefas));
}

function renderizar() {
  listaTarefas.innerHTML = "";

  tarefas.forEach((tarefa, indice) => {
    const li = document.createElement("li");
    if (tarefa.feita) li.classList.add("feita");

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = tarefa.feita;
    checkbox.addEventListener("change", () => alternarTarefa(indice));

    const texto = document.createElement("span");
    texto.textContent = tarefa.texto;

    const btnRemover = document.createElement("button");
    btnRemover.type = "button";
    btnRemover.textContent = "Remover";
    btnRemover.addEventListener("click", () => removerTarefa(indice));

    li.append(checkbox, texto, btnRemover);
    listaTarefas.appendChild(li);
  });

  const concluidas = tarefas.filter((t) => t.feita).length;
  resumo.textContent = tarefas.length === 0
    ? "Nenhuma tarefa cadastrada."
    : concluidas + " de " + tarefas.length + " tarefa(s) concluída(s).";
}

function adicionarTarefa() {
  const texto = inputTarefa.value.trim();
  if (texto === "") return;

  tarefas.push({ texto: texto, feita: false });
  salvarTarefas();
  renderizar();

  inputTarefa.value = "";
  inputTarefa.focus();
}

function alternarTarefa(indice) {
  tarefas[indice].feita = !tarefas[indice].feita;
  salvarTarefas();
  renderizar();
}

function removerTarefa(indice) {
  tarefas.splice(indice, 1);
  salvarTarefas();
  renderizar();
}

function apagarTodas() {
  if (tarefas.length === 0) return;
  if (confirm("Deseja apagar todas as tarefas?")) {
    tarefas = [];
    localStorage.removeItem(CHAVE_TAREFAS);
    renderizar();
  }
}

function aplicarTemaSalvo() {
  if (localStorage.getItem(CHAVE_TEMA) === "escuro") {
    document.body.classList.add("escuro");
  }
}

function alternarTema() {
  document.body.classList.toggle("escuro");
  const atual = document.body.classList.contains("escuro") ? "escuro" : "claro";
  localStorage.setItem(CHAVE_TEMA, atual);
}

btnAdicionar.addEventListener("click", adicionarTarefa);
inputTarefa.addEventListener("keydown", (e) => {
  if (e.key === "Enter") adicionarTarefa();
});
btnLimpar.addEventListener("click", apagarTodas);
btnTema.addEventListener("click", alternarTema);

aplicarTemaSalvo();
renderizar();
